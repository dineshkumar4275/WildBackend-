exports.requireRole = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Login required' });
    if (req.user.isBanned) {
      return res.status(403).json({ error: 'Your account is banned' });
    }
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        error: `Requires one of: ${allowedRoles.join(', ')}`,
      });
    }
    next();
  };
};